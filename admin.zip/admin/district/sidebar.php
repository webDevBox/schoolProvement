<div style="background-color: #5ca626" class="col-md-2 col-lg-2 col-sm-12 col-xs-12 ">

  <hr>
    <a href="distdash.php" class="w3-bar-item  item" style="margin-left:30px"><img src="icon/home.png" style="margin-bottom:5px; "> <?php echo $lang['dash'];?></a>
    <hr>
    <!-- <a href="student.php" class="w3-bar-item text-center item">Students</a>
    <hr>-->
    <a href="schoollist.php" class="w3-bar-item  item" style="margin-left:30px"><img src="icon/school.png" style="margin-bottom:5px; "> <?php echo $lang['sch'];?></a>
    <hr>
    <a href="profile.php" class="w3-bar-item item" style="margin-left:30px"><img src="icon/gear.png" style="margin-bottom:5px; "> <?php echo $lang['as'];?></a>
    <hr>

</div>