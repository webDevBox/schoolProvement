<?php
session_start();
session_destroy();
?>
          <script>
          window.location.href= '../index.html';
          </script>
          <?php
?>