<?php

$lang = array(
    "dad" => "Panel de administración del distrito",
    "cmail"=>"Cambiar e-mail",
    "ene"=>"Ingrese nuevo correo electrónico",
    "tpp"=>"Página de perfil del maestro",
    "dash" => "Tablero",
    "sch" => "Colegio",
    "as" => "Configuración de cuenta",
    "menu" => "Menú",    "principal" => "Principal",
    "teacher" => "Profesora",
    "school" => "Colegio",
    "block principal" => "Director de bloque",
    "ed" => "Exportar datos",
    "sr" => "Informe de la escuela",
    "tr" => "Informe del maestro",
    "dd" => "Panel del distrito",
    "ap" => "Agregar directora",
    "at" => "Agregar profesora",
    "add school" => "agregar escuela",
    "eop" => "Ingrese la contraseña anterior",
    "enp" => "Ingrese nueva clave",
    "cop" => "Conformar contraseña",
    "cp" => "Cambia la contraseña",
    "t" => "Total",
    "epn" => "Enter Principal Name",
    "epe" => "Enter Principal Email",
    "epc" => "Enter Principal Country",
    "spd" => "Select Principal District",
    "sps" => "Select Principal School",
    "lang_en" => "English",
    "lang_hi" => "हिन्दी",
    "lang_fr" => "française",
    "lang_sp" => "español",


);
?>