<?php

$name =$_POST['fname'];
$email =$_POST['email'];
$phone =$_POST['phone'];
$contact =$_POST['contact'];
$iam =$_POST['iam'];
$message =$_POST['message'];

die($iam);